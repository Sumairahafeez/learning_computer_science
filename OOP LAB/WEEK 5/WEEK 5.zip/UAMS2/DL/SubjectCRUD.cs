﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UAMS2.UL;

namespace UAMS2
{
    internal class SubjectCRUD
    {
       
    }
}
