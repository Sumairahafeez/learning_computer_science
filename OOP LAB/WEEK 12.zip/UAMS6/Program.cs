﻿using Labwork.BL;
using Labwork.DL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace UAMS6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Student st1 = new Student(12,"Fatima",230,1080,1040);
            DegreeProgram CS = new DegreeProgram();
            CS.Title = "CS";
            CS.Duration = 2;
            CS.subjects = new List<Subject>();


            st1.Prefrences = new List<DegreeProgram>();
            st1.Prefrences.Add(CS); 
            if(StudentDL.SaveStudent(st1))
            {
                Console.WriteLine("Student Added Succesfully ");
            }
            Student st2 = StudentDL.FindStudentByRoll("12");
            if(st2 != null)
            {
                Console.WriteLine(st2.Name+" "+st2.Roll+" "+st2.DegreeProgram);
            }
            else
            {
                Console.WriteLine("No Student Found");
            }

            Console.ReadKey();
        }
    }
}
