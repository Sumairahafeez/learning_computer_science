﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace L10Task2
{
    internal class Colors : IColors
    {
        private List<Color> _colors;
        private int _currentIndex;

        public Colors(List<Color> colors)
        {
            _colors = colors;
            _currentIndex = 0;
        }

        public Color GetNextColor()
        {
            if (_currentIndex == 2)
            {
                _currentIndex = -1;
            }
            _currentIndex = (_currentIndex + 1);
            return CurrentColor;
        }

        public Color GetPreviousColor()
        {
            if (_currentIndex == 0)
            {
                _currentIndex = 3;
            }
            _currentIndex = (_currentIndex - 1);
            return CurrentColor;
        }
        public Color CurrentColor => _colors[_currentIndex];
    }
 }