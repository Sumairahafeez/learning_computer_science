﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SocialMediaCollaboration.BL
{
    internal class LikesANDComments
    {
        private MUser User;
        private string Text;
        public void SetComments(string text)
        {
            Text = text;
        }
        public string GetComments()
        {
            return Text;
        }
        public void SetUser(MUser user)
        {
            User = user;
        }
        public MUser GetUser()
        {
            return User;
        }
        public LikesANDComments(MUser user)
        {
            User = user;
        }
        public LikesANDComments(MUser user, string text) : this(user)
        {
            Text = text;
        }
    }
}
