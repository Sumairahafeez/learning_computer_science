﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SocialMediaCollaboration.BL
{
    internal class MUser
    {
        private string Name;
        private string Password;

        List<MUser> Followers;
        List<MUser> Following;
        List<Posts> Posts;
        public MUser(string name, string password)
        {
            SetName(name);
            Password = password;
            Followers = new List<MUser>();
            Following = new List<MUser>();
            Posts = new List<Posts>();
        }
        public void SetName(string name)
        {
            Name = name;
        }
        public string GetName()
        {
            return Name;
        }
        public void SetPassword(string password)
        {
            Password = password;
        }
        public string GetPassword()
        {
            return Password;
        }
        public void CreatePost(string text)
        {
            Posts p = new Posts(text, this);
            Posts.Add(p);
        }

        public void AddFollower(MUser follower)
        {
            Followers.Add(follower);
        }

        public void AddFollowing(MUser following)
        {
            Following.Add(following);
        }
        public void ShowPosts()
        {
            Console.WriteLine("Posts by: " + Name);
            foreach (var post in Posts)
            {
                post.DisplayCommentsAndLikes();
                Console.WriteLine();
            }
        }
        public void ShowFollowers()
        {
            Console.WriteLine("Followers of: " + Name);
            foreach (var follower in Followers)
            {
                Console.WriteLine(follower.Name);
            }
        }
        public void ShowFollowings()
        {
            Console.WriteLine("Posts by: " + Name);
            foreach (var following in Following)
            {
                Console.WriteLine(following.Name);

            }
        }
    }
}
