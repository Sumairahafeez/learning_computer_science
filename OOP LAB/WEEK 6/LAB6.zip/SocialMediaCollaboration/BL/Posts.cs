﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;
using System.Xml.Linq;

namespace SocialMediaCollaboration.BL
{
    internal class Posts
    {
        private string Caption;
        private MUser User;
       
        private List<LikesANDComments> likes;
        private List<LikesANDComments> comments;
        public Posts() { }
        public Posts(string caption, MUser user)
        {
            SetCaption(caption);
            User = user;
            likes = new List<LikesANDComments>();
        }
        public void SetCaption(string caption)
        {
            Caption = caption;
        }
        public void SetUser(MUser user)
        {
            User = user;
        }
        public MUser GetUser()
        {
            return User;
        }
        public void AddLike(LikesANDComments like)
        {
            likes.Add(like);
        }



        public void AddComment(LikesANDComments comment)
        {
            comments.Add(comment);

        }

        
        public void DisplayCommentsAndLikes()
        {
            Console.WriteLine("Post: "+Caption);
            Console.WriteLine("Comments:");
            foreach (var comment in comments)
            {
                Console.WriteLine(comment.GetComments()+" by "+comment.GetUser().GetName());
            }
            Console.WriteLine("Likes:");
            foreach (var like in likes)
            {
                Console.WriteLine($"- Liked by {like.GetUser().GetName()}");
            }
        }

    }
}
