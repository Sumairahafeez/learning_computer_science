﻿using SocialMediaCollaboration.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SocialMediaCollaboration
{
    internal class Program
    {
        static void Main(string[] args)
        {   //User and Posts have a relation of Composition similarlu posts and comments or likes have a realtion of composition
            //where as user and followers and following have a relation of aggregation.
            MUser user1 = new MUser("Sumaira","1234");
            MUser user2 = new MUser("Sammra","1234");
            MUser user3 = new MUser("Tehreem","12345");
            user1.AddFollower(user2);
            user1.AddFollower(user3);
            user2.AddFollowing(user1);
            user3.AddFollowing(user1);
            user1.CreatePost("LIFE GOES ON CONTINUE THE JOUNEY");
            user1.ShowFollowers();
            user1.ShowFollowings();
            user1.ShowPosts();
            user2.CreatePost("HABUNALLAHU WA NIMAL WAQEEL");
            user2.ShowFollowers();
            user2.ShowFollowings();
            user2.ShowPosts();
            user3.CreatePost("ALLAH IS ENOUGH FOR US");
            user3.ShowFollowers();
            user3.ShowFollowings();
            user3.ShowPosts();
            Console.ReadKey();
        }
    }
}
