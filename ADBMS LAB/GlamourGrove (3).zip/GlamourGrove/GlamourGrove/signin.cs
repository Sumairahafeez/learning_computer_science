﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GlamourGrove
{
    public partial class signin : Form
    {
        public signin()
        {
            InitializeComponent();
            this.BackColor = Color.FromArgb(252, 231, 200);
        }
    }
}
